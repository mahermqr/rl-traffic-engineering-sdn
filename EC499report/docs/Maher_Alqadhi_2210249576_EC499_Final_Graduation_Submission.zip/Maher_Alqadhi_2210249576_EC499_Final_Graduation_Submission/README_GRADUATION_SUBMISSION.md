# EC499 Final Graduation Project Submission Dossier

**University of Tripoli &bull; Faculty of Engineering &bull; Department of Computer Engineering**  
**Project Title:** *Reinforcement Learning for Adaptive Traffic Engineering in an SDN Network*  
**Degree Candidate:** Maher Abdulnasir Alqadhi (Student ID: `2210249576`)  
**Project Supervisor:** Dr. Suad El-Geder (Associate Professor)  
**Submission Date:** October 2026  

---

## 1. Project Abstract
Static shortest-path routing frequently induces severe congestion along primary network trunks by assigning flows without considering real-time link loads or parallel capacity. This project presents an adaptive, closed-loop Software-Defined Networking (SDN) traffic engineering architecture combining a Ryu OpenFlow 1.3 controller, a NetworkX global topology model, and a PyTorch Dueling Double Deep Q-Network (D3QN) with Prioritized Experience Replay. Candidate paths are dynamically selected using a normalized ten-dimensional state representation capturing hop count, bottleneck utilization, propagation delay, and network-wide load.

The architecture was evaluated against conventional baselines, including OSPF, Dijkstra SPF, Equal-Cost Multi-Path (ECMP), Widest Shortest Path (WSP), Least-Loaded Routing (LLR), and an exact Unsplittable Multi-Commodity Flow integer linear programming oracle solved via HiGHS. Across benchmark topologies and two-way cluster bootstrap analyses with 95% confidence intervals, the D3QN agent significantly outperformed static routing, achieving up to 23.07% bottleneck utilization relief while reducing latency and packet loss. An architectural ablation demonstrated that dueling streams drive the primary latency reduction, while hierarchical variance analysis across five independent seeds proved that weight initialization contributes only 0.73% to performance variance. Furthermore, zero-shot evaluation on held-out topologies confirmed robust out-of-distribution transfer without retraining. With sub-millisecond inference (0.04 ms), carrier-grade controller failover, and discrete-event queue validation, the system provides a mathematically grounded, reproducible foundation for intelligent software-defined networks.

---

## 2. Directory Layout & Manifest

```text
Maher_Alqadhi_2210249576_EC499_Final_Graduation_Submission/
├── README_GRADUATION_SUBMISSION.md        <- This authoritative dossier
├── CHECKSUMS_SHA256.txt                   <- Cryptographic SHA256 integrity hashes
│
├── 01_Final_Thesis_Report/
│   ├── Project_Report_EC499_Final.pdf     <- Authoritative Master Thesis PDF (85 pages)
│   ├── Project_Report_EC499_Final.docx    <- Authoritative Master Thesis DOCX (Word Document)
│   ├── Project_Report_EC499_Monolithic.tex<- Monolithic LaTeX document (3,886 lines)
│   ├── main.tex                           <- Clean Root LaTeX file
│   ├── references.bib                     <- Complete academic bibliography
│   ├── chapters/                          <- All 11 thesis chapters (Modular LaTeX)
│   └── appendices/                        <- All 5 technical appendices (Modular LaTeX)
│
├── 02_Defense_Presentation/
│   ├── EC499_Graduation_Defense_Presentation.pptx <- 30-Slide PowerPoint Presentation Deck
│   ├── EC499_Graduation_Defense_Slides.html       <- Standalone Interactive HTML5 Deck
│   └── DEFENSE_CHEAT_SHEET.md                     <- 5-Minute Demo Runbook & 11 Committee Q&As
│
├── 03_Experimental_Figures_and_Plots/     <- All 15 High-Resolution Publication Plots
│   ├── proposal_benchmarks_all_metrics.png
│   ├── proposal_tournament_radar.png
│   ├── dqn_te_training_convergence.png
│   ├── routing_cdfs_latency_jitter.png
│   ├── stress_test_load_balancing.png
│   ├── blind_topologies_radar.png
│   ├── blind_topologies_stress_benchmark.png
│   ├── traffic_load_scaling_curves.png
│   ├── random_blind_topologies_evaluation.png
│   ├── dashboard_topology_telemetry.png
│   ├── dashboard_versus_tournament.png
│   ├── dashboard_model_inspector.png
│   ├── dashboard_network_settings.png
│   ├── pareto_weight_sensitivity.png
│   └── vmware_virtual_machine_specs.png
│
├── 04_Validation_Logs_and_Metrics/        <- Benchmark Data and Validation Records
│   ├── validation_matrix_S7_udp_20261015_075319.csv <- Official Mininet Emulation Matrix
│   ├── training_metrics.csv               <- 500-Episode D3QN Training Convergence Log
│   ├── evaluation_results.json            <- Multi-topology evaluation records
│   ├── routing_tournament_results.json    <- 6-protocol tournament benchmark records
│   └── pareto_sensitivity_ablation.json   <- Pareto weight sensitivity ablation records
│
├── 05_Trained_D3QN_Model/
│   └── dqn_router.pth                     <- Optimized PyTorch Neural Network Weights
│
└── 06_Source_Code_and_Dashboard/          <- Carrier-Grade Python 3.10+ Codebase
    ├── controller/                        <- Ryu SDN controller, state manager, web dashboard
    ├── agent/                             <- D3QN model and replay buffer
    ├── topology/                          <- Network graphs and Mininet fabrics
    ├── config.py                          <- Centralized runtime configuration
    ├── benchmark_routing_algorithms.py    <- 6-Protocol Tournament Benchmark Runner
    ├── stress_test_blind_topologies.py    <- Zero-Shot Generalization Test Runner
    ├── ablate_reward_weights.py           <- Pareto Sensitivity Ablation Suite
    ├── audit_dqn_agent_deep.py            <- Deep Mathematical & Policy Audit Suite
    ├── run_tests.sh                       <- 32-Test Automated Unit & Integration Suite
    └── requirements.txt                   <- Python Dependencies Manifest
```

---

## 3. Quickstart & Verification Instructions

### A. Running the Automated Test Suite
```bash
cd 06_Source_Code_and_Dashboard
bash run_tests.sh
```
*Expected Result:* all tests complete with `OK`.

### B. Launching the Interactive Web Dashboard
```bash
cd 06_Source_Code_and_Dashboard
python3 controller/web_dashboard.py
```
Open **Google Chrome** to `http://localhost:8080`.

### C. Viewing Presentation Slides
- Open `02_Defense_Presentation/EC499_Graduation_Defense_Slides.html` in Google Chrome (press `F` for Fullscreen, `N` for Speaker Notes).
- Open `02_Defense_Presentation/EC499_Graduation_Defense_Presentation.pptx` in Microsoft PowerPoint.

---

## 4. Archived Performance Indicators

The values below are historical results carried in the submitted logs. Re-run the bundled
tests and benchmarks on the target environment before citing them as current measurements.

| Metric | Classical Baseline (OSPF/ECMP) | Proposed D3QN Agent | Measured Benefit |
| :--- | :--- | :--- | :--- |
| **UDP Throughput Delivery** | 38.18 Mbps | **64.89 Mbps** | **+69.9% gain (99.8% line-rate)** |
| **Delay Variation (Jitter)**| 6.97 ms | **1.71 ms** | **76.2% jitter suppression** |
| **Packet Loss Rate** | 4.37% | **0.01%** | **450x loss eradication** |
| **TCP Goodput** | Window deflation | **63.88 Mbps** | **Clean, smooth window growth** |
| **Core Jamming Relief** | 95.05% bottleneck | **53.01% bottleneck** | **+42.04% congestion relief** |
| **Inference Decision Speed**| N/A | **<0.05 ms** | **>2,400 decisions/second** |
| **Zero-Shot Transfer (10 Graphs)** | High failure | **100% Win Rate** | **Invariant across 15–35 nodes** |

---

*Compiled and certified for graduation defense examination, Faculty of Engineering, University of Tripoli.*
