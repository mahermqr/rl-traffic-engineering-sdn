# EC499 Final Graduation Project Submission Dossier

**University of Tripoli &bull; Faculty of Engineering &bull; Department of Computer Engineering**  
**Project Title:** *Reinforcement Learning for Adaptive Traffic Engineering in an SDN Network*  
**Degree Candidate:** Maher Abdulnasir Alqadhi (Student ID: `2210249576`)  
**Project Supervisor:** Dr. Suad El-Geder  
**Submission Date:** Spring 2026  

---

## 1. Project Abstract
Static shortest-path routing frequently induces severe congestion along primary network trunks by assigning flows without considering real-time link loads or parallel capacity. This project presents an adaptive, closed-loop Software-Defined Networking (SDN) traffic engineering architecture combining a Ryu OpenFlow 1.3 controller, a NetworkX global topology model, and a PyTorch Dueling Double Deep Q-Network (D3QN) with Prioritized Experience Replay. Candidate paths are dynamically selected using a normalized ten-dimensional state representation capturing hop count, bottleneck utilization, propagation delay, and network-wide load.

The architecture was evaluated against conventional baselines, including OSPF, Dijkstra SPF, Equal-Cost Multi-Path (ECMP), Widest Shortest Path (WSP), Least-Loaded Routing (LLR), and an exact Unsplittable Multi-Commodity Flow integer linear programming oracle solved via HiGHS. Across benchmark topologies and two-way cluster bootstrap analyses with 95% confidence intervals, the D3QN agent significantly outperformed static routing, achieving up to 23.07% bottleneck utilization relief while reducing latency and packet loss. An architectural ablation demonstrated that dueling streams drive the primary latency reduction, while hierarchical variance analysis across five independent seeds proved that weight initialization contributes only 0.73% to performance variance. Furthermore, zero-shot evaluation on held-out topologies confirmed robust out-of-distribution transfer without retraining. With sub-millisecond inference (0.04 ms), carrier-grade controller failover, and discrete-event queue validation, the system provides a mathematically grounded, reproducible foundation for intelligent software-defined networks.

---

## 2. Directory Layout & Manifest

```text
Maher_Alqadhi_2210249576_EC499_Final_Graduation_Submission/
├── README_GRADUATION_SUBMISSION.md        <- This authoritative dossier
├── CHECKSUMS_SHA256.txt                   <- Cryptographic SHA256 integrity hashes
│
├── 01_Thesis_Document/
│   ├── Project_Report_EC499_Final.pdf     <- Authoritative Master Thesis PDF (82 pages)
│   ├── Project_Report_EC499_Final.docx    <- Authoritative Master Thesis DOCX (Word Document)
│   ├── Project_Report_EC499_Final.tex     <- Monolithic LaTeX document (4,150+ lines)
│   ├── main.tex                           <- Clean Root LaTeX file
│   ├── references.bib                     <- Complete academic bibliography
│   ├── chapters/                          <- Thesis chapters (Modular LaTeX)
│   └── appendices/                        <- Technical appendices (Modular LaTeX)
│
├── 02_Examination_Handout/
│   ├── mahermqr.pdf                       <- 4-Page Examination Defense Handout PDF
│   ├── mahermqr.docx                      <- Editable Word Handout
│   ├── mahermqr.md                        <- Markdown Handout
│   └── mahermqr.tex                       <- LaTeX Source for Handout
│
├── 03_Defense_Presentation/
│   ├── EC499_Defense_Slides.pdf           <- Presentation Slides PDF
│   ├── EC499_Final_Defense_Presentation.pptx <- PowerPoint Presentation Deck
│   ├── EC499_Defense_Deck_Interactive.html <- Standalone Interactive HTML5 Deck
│   ├── slides.css                         <- Presentation Stylesheet
│   ├── slides.js                          <- Interactive Presentation Scripts
│   ├── DEFENSE_CHEAT_SHEET.md             <- 5-Minute Demo Runbook & Committee Q&As
│   └── VIVA_DEFENSE_MASTER_GUIDE.md       <- Complete Oral Examination Defense Guide
│
├── 04_Source_Code/                        <- Carrier-Grade Python 3.10+ Codebase
│   ├── controller/                        <- Ryu SDN controller, state manager, web dashboard
│   ├── agent/                             <- D3QN model and replay buffer
│   ├── topology/                          <- Network graphs and Mininet fabrics
│   ├── report_builder/                    <- Automated LaTeX report generation pipeline
│   ├── config.py                          <- Centralized runtime configuration
│   ├── benchmark_routing_algorithms.py    <- 6-Protocol Tournament Benchmark Runner
│   ├── stress_test_blind_topologies.py    <- Zero-Shot Generalization Test Runner
│   ├── ablate_reward_weights.py           <- Pareto Sensitivity Ablation Suite
│   ├── audit_dqn_agent_deep.py            <- Deep Mathematical & Policy Audit Suite
│   ├── run_tests.sh                       <- 42-Test Automated Unit & Integration Suite
│   └── requirements.txt                   <- Python Dependencies Manifest
│
├── 05_Trained_Models/
│   └── dqn_router.pth                     <- Optimized PyTorch Neural Network Weights
│
└── 06_Test_Reports/                       <- Validation Records, Benchmarks & Figures
    ├── mininet_matrix/                    <- Official Mininet Emulation Matrix
    ├── training_metrics.csv               <- D3QN Training Convergence Log
    ├── evaluation_results.json            <- Multi-topology evaluation records
    ├── routing_tournament_results.json    <- 6-protocol tournament benchmark records
    ├── pareto_sensitivity_ablation.json   <- Pareto weight sensitivity ablation records
    ├── figures/                           <- High-Resolution Publication Plots & UI Captures
    └── demo2026/                          <- Interactive Demo Suite & Scenarios
```

---

## 3. Quickstart & Verification Instructions

### A. Running the Automated Test Suite
```bash
cd 04_Source_Code
bash run_tests.sh
```
*Expected Result:* all tests complete with `OK`.

### B. Launching the Interactive Web Dashboard
```bash
cd 04_Source_Code
python3 controller/web_dashboard.py
```
Open **Google Chrome** to `http://localhost:8080`.

### C. Viewing Presentation Slides
- Open `03_Defense_Presentation/EC499_Defense_Deck_Interactive.html` in Google Chrome (press `F` for Fullscreen, `N` for Speaker Notes).
- Open `03_Defense_Presentation/EC499_Final_Defense_Presentation.pptx` in Microsoft PowerPoint.

---

## 4. Archived Performance Indicators

The values below are historical results carried in the submitted logs. Re-run the bundled
tests and benchmarks on the target environment before citing them as current measurements.

| Metric | Classical Baseline (OSPF/ECMP) | Proposed D3QN Agent | Measured Benefit |
| :--- | :--- | :--- | :--- |
| **UDP Throughput Delivery** | 38.18 Mbps | **64.89 Mbps** | **+69.9% gain (99.8% line-rate)** |
| **Delay Variation (Jitter)**| 6.97 ms | **1.71 ms** | **76.2% jitter suppression** |
| **Packet Loss Rate** | 4.37% | **0.01%** | **450x loss eradication** |
| **TCP Goodput** | Window deflation | **63.88 Mbps** | **Clean, smooth window growth** |
| **Core Jamming Relief** | 95.05% bottleneck | **53.01% bottleneck** | **+42.04% congestion relief** |
| **Inference Decision Speed**| N/A | **<0.05 ms** | **>2,400 decisions/second** |
| **Zero-Shot Transfer (10 Graphs)** | High failure | **100% Win Rate** | **Invariant across 15–35 nodes** |

---

*Compiled and certified for graduation defense examination, Faculty of Engineering, University of Tripoli.*
