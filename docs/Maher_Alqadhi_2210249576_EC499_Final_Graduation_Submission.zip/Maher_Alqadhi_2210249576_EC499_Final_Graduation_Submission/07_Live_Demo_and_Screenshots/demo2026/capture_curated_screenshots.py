#!/usr/bin/env python3
"""
Curated Screenshot Capture Suite for EC499 Graduation Demo & Final Report.
Captures high-resolution, un-clipped, publication-ready screenshots of:
1. ha_cluster_3node_modal.png - 3-Node HA Controller Cluster (Master + 2 Hot-Standby)
2. d3qn_route_predictor_verdict.png - Interactive Route Predictor with D3QN Victory Verdict (-81% bottleneck)
3. tournament_6protocol_benchmarks.png - 6-Protocol Tournament & Radar/Latency Triad Plots
4. full_dashboard_panoramic.png - Full-page high-resolution dashboard panoramic
"""

import os
import time
import json
import urllib.request
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "screenshots")
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)

CONTROLLER_URL = "http://127.0.0.1:8080"

def api_post(endpoint, data=None):
    url = f"{CONTROLLER_URL}{endpoint}"
    payload = json.dumps(data or {}).encode('utf-8')
    req = urllib.request.Request(
        url, data=payload,
        headers={'Content-Type': 'application/json', 'User-Agent': 'EC499-Capture/1.0'},
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        print(f"[-] POST {endpoint} error: {e}")
        return {}

def main():
    print("=" * 80)
    print(" 📸 CAPTURING CURATED PUBLICATION-READY SCREENSHOTS FOR EC499")
    print("=" * 80)

    options = Options()
    options.binary_location = "/home/maher/.local/bin/google-chrome"
    options.add_argument('--headless=new')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-gpu')
    options.add_argument('--window-size=1680,1200')

    driver = webdriver.Chrome(options=options)

    try:
        driver.get(CONTROLLER_URL)
        time.sleep(2.5)

        # -------------------------------------------------------------
        # 1. HA CLUSTER 3-NODE MODAL SCREENSHOT
        # -------------------------------------------------------------
        print("\n[1/4] Capturing Multi-Controller HA Cluster Modal...")
        driver.execute_script("""
            if (typeof openHaClusterModal === 'function') {
                openHaClusterModal();
            }
            const modalBackdrop = document.getElementById('haClusterModal');
            if (modalBackdrop) {
                modalBackdrop.style.display = 'flex';
                modalBackdrop.style.opacity = '1';
                modalBackdrop.style.visibility = 'visible';
            }
            const modalBody = document.querySelector('#haClusterModal .modal-body');
            if (modalBody) {
                modalBody.style.maxHeight = 'none';
                modalBody.style.overflow = 'visible';
            }
            const modalDialog = document.querySelector('#haClusterModal .modal-dialog');
            if (modalDialog) {
                modalDialog.style.maxHeight = 'none';
                modalDialog.style.overflow = 'visible';
                modalDialog.style.boxShadow = '0 25px 60px -15px rgba(0,0,0,0.3)';
            }
        """)
        time.sleep(1.2)
        
        modal_dialog = driver.find_element("css selector", "#haClusterModal .modal-dialog")
        ha_img_path = os.path.join(SCREENSHOTS_DIR, "ha_cluster_3node_modal.png")
        modal_dialog.screenshot(ha_img_path)
        print(f"[✓] Saved: ha_cluster_3node_modal.png ({os.path.getsize(ha_img_path)/1024:.1f} KB)")

        # Close modal
        driver.execute_script("""
            if (typeof closeHaClusterModal === 'function') {
                closeHaClusterModal();
            }
            const modalBackdrop = document.getElementById('haClusterModal');
            if (modalBackdrop) {
                modalBackdrop.style.display = 'none';
            }
        """)
        time.sleep(0.8)

        # -------------------------------------------------------------
        # 2. ROUTE PREDICTOR WITH D3QN VICTORY VERDICT & ACTIONS TABLE
        # -------------------------------------------------------------
        print("\n[2/4] Capturing Route Predictor & D3QN vs OSPF Victory Verdict...")
        # Trigger core congestion surge via the UI button
        btn = driver.find_element("xpath", '//button[contains(., "Core Congestion Surge")]')
        btn.click()
        time.sleep(2.0)

        # Set demo pair (s2 -> s3 with 40 Mbps)
        driver.execute_script("setDemoPair(2, 3, 40);")
        time.sleep(2.0)

        # Target the route predictor section (second .dash-card)
        pred_card = driver.find_elements("css selector", ".dash-card")[1]
        driver.execute_script("arguments[0].scrollIntoView({block: 'start'});", pred_card)
        time.sleep(0.8)

        pred_img_path = os.path.join(SCREENSHOTS_DIR, "d3qn_route_predictor_verdict.png")
        pred_card.screenshot(pred_img_path)
        print(f"[✓] Saved: d3qn_route_predictor_verdict.png ({os.path.getsize(pred_img_path)/1024:.1f} KB)")

        # -------------------------------------------------------------
        # 3. ALGORITHM TOURNAMENT & BENCHMARKING TRIAD CHARTS
        # -------------------------------------------------------------
        print("\n[3/4] Capturing Algorithm Tournament & Benchmarking Triad...")
        tourn_card = driver.find_element("css selector", "#tournamentSection")
        driver.execute_script("arguments[0].scrollIntoView({block: 'start'});", tourn_card)
        time.sleep(1.0)

        tourn_img_path = os.path.join(SCREENSHOTS_DIR, "tournament_6protocol_benchmarks.png")
        tourn_card.screenshot(tourn_img_path)
        print(f"[✓] Saved: tournament_6protocol_benchmarks.png ({os.path.getsize(tourn_img_path)/1024:.1f} KB)")

        # -------------------------------------------------------------
        # 4. FULL DASHBOARD PANORAMIC (TOPOLOGY + METRICS + PREDICTOR)
        # -------------------------------------------------------------
        print("\n[4/4] Capturing Full Dashboard Upper Panoramic...")
        driver.execute_script("window.scrollTo(0, 0);")
        time.sleep(0.8)

        driver.set_window_size(1680, 1100)
        panoramic_path = os.path.join(SCREENSHOTS_DIR, "dashboard_upper_panoramic.png")
        driver.save_screenshot(panoramic_path)
        print(f"[✓] Saved: dashboard_upper_panoramic.png ({os.path.getsize(panoramic_path)/1024:.1f} KB)")

        # Reset fabric back to nominal
        api_post("/api/simulate/reset")
        api_post("/api/simulate/link_restore")

    finally:
        driver.quit()

    print("\n" + "=" * 80)
    print(" 🎯 ALL CURATED SCREENSHOTS CAPTURED SUCCESSFULLY!")
    print("=" * 80)

if __name__ == '__main__':
    main()
