# EC499 Final Graduation Project Submission Dossier

**University of Tripoli &bull; Faculty of Engineering &bull; Department of Computer Engineering**  
**Project Title:** *Reinforcement Learning for Adaptive Traffic Engineering in an SDN Network*  
**Degree Candidate:** Maher Abdulnasir Alqadhi (Student ID: `2210249576`)  
**Project Supervisor:** Dr. Suad El-Geder (Associate Professor)  
**Submission Date:** October 2026  

---

## 1. Executive Summary & Abstract
This graduation project addresses the fundamental traffic engineering challenges in modern Software-Defined Networks (SDN) under bursty, non-stationary traffic regimes. Classical shortest-path routing protocols (OSPF, ECMP, Dijkstra SPF) and myopic greedy heuristics (Least Loaded Routing, Widest Shortest Path) are structurally vulnerable to core trunk congestion, buffer overflow drops, and herd behavior.

We design, implement, and empirically validate an end-to-end, closed-loop adaptive traffic engineering architecture combining:
1. **Ryu SDN Controller (OpenFlow 1.3):** Real-time global network state estimation, non-intrusive port statistics polling, and candidate path synthesis via Yen's K-Shortest Paths.
2. **Dueling Double Deep Q-Network (D3QN):** Scale-invariant 10-dimensional continuous state vector normalization, decoupling state value from candidate path advantage, and Prioritized Experience Replay via a non-recursive binary SumTree.
3. **Multi-Objective Pareto Reward with Asymptotic Congestion Barrier:** Dynamically optimizes throughput, RFC 3393 delay variation, and M/M/1/K buffer loss, while imposing an exponential barrier when link utilization exceeds 70%.
4. **Physical Mininet Emulation:** Proven line-rate delivery (64.89 Mbps of 65 Mbps UDP stream), 76.2% delay jitter suppression, and 450x packet loss eradication.
5. **Interactive Operations Web Dashboard:** Real-time topology canvas, live route forecasting, chaos failover console, and head-to-head tournament arena.

---

## 2. Directory Layout & Manifest

```text
Maher_Alqadhi_2210249576_EC499_Final_Graduation_Submission/
├── README_GRADUATION_SUBMISSION.md        <- This authoritative dossier
├── CHECKSUMS_SHA256.txt                   <- Cryptographic SHA256 integrity hashes
│
├── 01_Final_Thesis_Report/
│   ├── Project_Report_EC499_Final.pdf     <- Authoritative 107-Page Master Thesis PDF
│   ├── Project_Report_EC499_Monolithic.tex<- Monolithic LaTeX document (3,861 lines)
│   ├── references.bib                     <- Complete academic bibliography
│   ├── chapters/                          <- All 11 thesis chapters (Modular LaTeX)
│   └── appendices/                        <- All 5 technical appendices (Modular LaTeX)
│
├── 02_Defense_Presentation/
│   ├── EC499_Graduation_Defense_Presentation.pptx <- 30-Slide PowerPoint Presentation Deck
│   ├── EC499_Graduation_Defense_Slides.html       <- Standalone Interactive HTML5 Deck
│   └── DEFENSE_CHEAT_SHEET.md                     <- 5-Minute Demo Runbook & 11 Committee Q&As
│
├── 03_Experimental_Figures_and_Plots/     <- All 14 High-Resolution Publication Plots
│   ├── proposal_benchmarks_all_metrics.png
│   ├── proposal_tournament_radar.png
│   ├── dqn_te_training_convergence.png
│   ├── routing_cdfs_latency_jitter.png
│   ├── stress_test_load_balancing.png
│   ├── blind_topologies_radar.png
│   ├── blind_topologies_stress_benchmark.png
│   ├── traffic_load_scaling_curves.png
│   ├── random_blind_topologies_evaluation.png
│   ├── dashboard_topology_telemetry.png
│   ├── dashboard_versus_tournament.png
│   ├── dashboard_model_inspector.png
│   ├── dashboard_network_settings.png
│   └── pareto_weight_sensitivity.png
│
├── 04_Validation_Logs_and_Metrics/        <- Empirical Validation Matrices
│   ├── validation_matrix_S7_udp_20261015_075319.csv <- Official Mininet Emulation Matrix
│   ├── training_metrics.csv               <- 500-Episode D3QN Training Convergence Log
│   ├── evaluation_results.json            <- Multi-topology evaluation records
│   ├── routing_tournament_results.json    <- 6-protocol tournament benchmark records
│   └── pareto_sensitivity_ablation.json   <- Pareto weight sensitivity ablation records
│
├── 05_Trained_D3QN_Model/
│   └── dqn_router.pth                     <- Optimized PyTorch Neural Network Weights
│
└── 06_Source_Code_and_Dashboard/          <- Carrier-Grade Python 3.10+ Codebase
    ├── controller/                        <- Ryu SDN controller, state manager, web dashboard
    ├── simulation/                        <- Network environment, flow generator, topologies
    ├── benchmark_routing_algorithms.py    <- 6-Protocol Tournament Benchmark Runner
    ├── stress_test_blind_topologies.py    <- Zero-Shot Generalization Test Runner
    ├── ablate_reward_weights.py           <- Pareto Sensitivity Ablation Suite
    ├── audit_dqn_agent_deep.py            <- Deep Mathematical & Policy Audit Suite
    ├── run_tests.sh                       <- 32-Test Automated Unit & Integration Suite
    └── requirements.txt                   <- Python Dependencies Manifest
```

---

## 3. Quickstart & Verification Instructions

### A. Running the Automated Test Suite (32 Tests)
```bash
cd 06_Source_Code_and_Dashboard
bash run_tests.sh
```
*Expected Result:* `Ran 32 tests ... OK (100% Success)`

### B. Launching the Interactive Web Dashboard
```bash
cd 06_Source_Code_and_Dashboard
python3 controller/web_dashboard.py
```
Open **Google Chrome** to `http://localhost:8080`.

### C. Viewing Presentation Slides
- Open `02_Defense_Presentation/EC499_Graduation_Defense_Slides.html` in Google Chrome (press `F` for Fullscreen, `N` for Speaker Notes).
- Open `02_Defense_Presentation/EC499_Graduation_Defense_Presentation.pptx` in Microsoft PowerPoint.

---

## 4. Key Performance Indicators (From Official Mininet Logs)

| Metric | Classical Baseline (OSPF/ECMP) | Proposed D3QN Agent | Measured Benefit |
| :--- | :--- | :--- | :--- |
| **UDP Throughput Delivery** | 38.18 Mbps | **64.89 Mbps** | **+69.9% gain (99.8% line-rate)** |
| **Delay Variation (Jitter)**| 6.97 ms | **1.71 ms** | **76.2% jitter suppression** |
| **Packet Loss Rate** | 4.37% | **0.01%** | **450x loss eradication** |
| **TCP Goodput** | Window deflation | **63.88 Mbps** | **Clean, smooth window growth** |
| **Core Jamming Relief** | 95.05% bottleneck | **53.01% bottleneck** | **+42.04% congestion relief** |
| **Inference Decision Speed**| N/A | **<0.05 ms** | **>2,400 decisions/second** |
| **Zero-Shot Transfer (10 Graphs)** | High failure | **100% Win Rate** | **Invariant across 15–35 nodes** |

---

*Compiled and certified for graduation defense examination, Faculty of Engineering, University of Tripoli.*
